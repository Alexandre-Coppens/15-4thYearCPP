// q3map_sun <red> <green> <blue> <intensity> <degrees> <elevation>
// color will be normalized, so it doesn't matter what range you use
// intensity falls off with angle but not distance 100 is a fairly bright sun
// degree of 0 = from the east, 90 = north, etc.  altitude of 0 = sunrise/set, 90 = noon
textures/666/xian_dark
{
	qer_editorimage textures/skies/xnight2_up.tga
	surfaceparm noimpact
	surfaceparm nolightmap
	skyParms env/xnight2 128 -
}

textures/666/666_hellfog_1k
{
	qer_editorimage textures/sfx/fog_red.tga
	surfaceparm fog
	surfaceparm nodrop
	surfaceparm nolightmap
	surfaceparm nonsolid
	surfaceparm trans
	q3map_surfacelight 3
	q3map_globaltexture
	fogparms ( 1 0 0 ) 256
	{
		map textures/liquids/kc_fogcloud3.tga
		blendfunc filter
		rgbGen identity
		tcMod scale -0.05 -0.05
		tcMod scroll 0.02 -0.02
	}
	{
		map textures/liquids/kc_fogcloud3.tga
		blendfunc filter
		rgbGen identity
		tcMod scale 0.05 0.05
		tcMod scroll 0.025 -0.025
	}
}

textures/666/666_ironcrossltred_500
{
	qer_editorimage textures/gothic_light/ironcrossltred.tga
	q3map_lightimage textures/gothic_light/ironcrossltred.blend.tga
	surfaceparm nomarks
	q3map_surfacelight 875
	{
		map $lightmap 
		rgbGen identity
		tcGen lightmap 
	}
	{
		map textures/gothic_light/ironcrossltred.tga
		blendfunc filter
		rgbGen identity
	}
	{
		map textures/gothic_light/ironcrossltred.blend.tga
		blendfunc add
		rgbGen identity
	}
}

textures/666/666_ironcrossltred_1000
{
	qer_editorimage textures/gothic_light/ironcrossltred.tga
	q3map_lightimage textures/gothic_light/ironcrossltred.blend.tga
	surfaceparm nomarks
	q3map_surfacelight 1000
	{
		map $lightmap 
		rgbGen identity
		tcGen lightmap 
	}
	{
		map textures/gothic_light/ironcrossltred.tga
		blendfunc filter
		rgbGen identity
	}
	{
		map textures/gothic_light/ironcrossltred.blend.tga
		blendfunc add
		rgbGen identity
	}
}

textures/666/666_lavahell_100
{
	qer_editorimage textures/liquids/lavahell.tga
	surfaceparm lava
	surfaceparm noimpact
	surfaceparm nolightmap
	surfaceparm trans
	cull disable
	deformVertexes wave 100 sin 3 2 0.1 0.1 
	tessSize 128
	q3map_surfacelight 110
	q3map_globaltexture
	{
		map textures/liquids/lavahell.tga
		rgbGen identity
		tcMod turb 0 0.2 0 0.1
	}
}

textures/666/666_hellfog_deathpit
{
	qer_editorimage textures/sfx/fog_red.tga
	surfaceparm fog
	surfaceparm nodrop
	surfaceparm nolightmap
	surfaceparm nonsolid
	surfaceparm trans
	q3map_surfacelight 30
	q3map_globaltexture
	fogparms ( 1 0 0 ) 512
	{
		map textures/liquids/kc_fogcloud3.tga
		blendfunc filter
		rgbGen identity
		tcMod scale -0.05 -0.05
		tcMod scroll 0.02 -0.02
	}
	{
		map textures/liquids/kc_fogcloud3.tga
		blendfunc filter
		rgbGen identity
		tcMod scale 0.05 0.05
		tcMod scroll 0.025 -0.025
	}
}

