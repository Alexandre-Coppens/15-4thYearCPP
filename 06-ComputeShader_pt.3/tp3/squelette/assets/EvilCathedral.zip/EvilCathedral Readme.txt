=================================================================================
The Evil Cathedral					      Quake III Arena Map
=================================================================================


                                  16/12/2001


------General Information--------------------------------------------------------
---------------------------------------------------------------------------------


Title		 : The Evil Cathedral
Filename	 : EvilCathedral.pk3
Mapname		 : EvilCathedral.bsp  
Author		 : [D.A.]Vincent Vega
E-mail		 : fronkel@gmx.de
ICQ              : 36478687
Website          : http://www.virtual-ass-kickers.de

Description	 : Large FFA map for Quake3
		   
Previous Maps	 : HalfLife Counterstrike: cs_nighthawkv2, cs_urbanterror

			
------Play Information-----------------------------------------------------------
---------------------------------------------------------------------------------


Game Type       : Free for All, Instagib, maybe Tournament

Players		: 50 Playerspawnpoints :o) 

Bots		: they work, but the map was not designed with botplay in mind 

Specials        : the 2 healthbubbles on the opening hatches give you 75 health
                  points instead of 50 (standard). 
                  
                  megahealth boosts your health always to 200 points.
                  
                  shoot one of the 4 buttons on the upper level inside the 
                  cathedral to lower the ceiling in the small 
                  room where the red armor resides > kills campers up there;)

                  sounds: listen carefully to ambient sounds: some weapons
                  trigger ambient sounds when picked up (eg. the rocketlauncher
                  in the cathedral triggers a bell) > its a good way to track 
                  where your enemies are;)
  
                 
------Map Information------------------------------------------------------------
---------------------------------------------------------------------------------


Brushes         : 4785

Entities        : 748 


------Construction---------------------------------------------------------------
---------------------------------------------------------------------------------
 

Base		: idea in my head;)

Editor(s) used	: Q3Radiant from the first version till the actual one (202),
                  also GTK Radiant

Build time      : around 2 years with many, many long breaks  

Compile Machine	: TBird 1400 / 512 MB DDRRAM

Final 
Compiletime     : around 3 Hours


------Credits and Thanks---------------------------------------------------------
---------------------------------------------------------------------------------


- RiceBug from www.qeradiant.com for his kind help

- Claudec for his awesome Q3 mapping resource site www.claudec.com

- Kahless from [BohW]Clan for putting this map on his server for many days of
  betatesting www.bohw-clan.de

- all people from the planetquake.de forums for their feedback

- TNSO for great LAN parties :o) www.networksession.de
  
- and finally: all people who motivated me to complete this map!


------Installation Instructions--------------------------------------------------
---------------------------------------------------------------------------------


Unzip EvilCathedral.zip. Place the EvilCathedral.pk3 file in your baseq3 directory.

IMPORTANT: if you got an older version of this map > move the old file out of your 
Quake 3 directory or delete it. If you leave it in or just rename the old file you 
won't see some shaders/textures properly:(


------Other Notes----------------------------------------------------------------
---------------------------------------------------------------------------------

Have phun & frag hard;)